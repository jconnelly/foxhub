-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2019 at 06:45 AM
-- Server version: 5.7.21
-- PHP Version: 7.1.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foxhub`
--

-- --------------------------------------------------------

--
-- Table structure for table `bol_head`
--

CREATE TABLE `bol_head` (
  `id` int(4) NOT NULL,
  `user_id` int(4) NOT NULL,
  `carrier_name` varchar(100) DEFAULT NULL,
  `carrier_duns` varchar(100) DEFAULT NULL,
  `carrier_phone` varchar(100) DEFAULT NULL,
  `carrier_address` varchar(200) DEFAULT NULL,
  `carrier_date` datetime DEFAULT NULL,
  `consignee` varchar(100) DEFAULT NULL,
  `consignee_address` varchar(100) DEFAULT NULL,
  `consignee_phone` varchar(100) DEFAULT NULL,
  `third_party_billing` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `bol_number` varchar(100) DEFAULT NULL,
  `sid_number` varchar(100) DEFAULT NULL,
  `sac` varchar(100) DEFAULT NULL,
  `freight_bill_pro_number` varchar(100) DEFAULT NULL,
  `load_number` varchar(100) DEFAULT NULL,
  `trailer_number` varchar(100) DEFAULT NULL,
  `trailer_type` varchar(100) DEFAULT NULL,
  `special_instructions1` varchar(100) DEFAULT NULL,
  `shipper_internal_date` varchar(100) DEFAULT NULL,
  `special_instructions2` varchar(100) DEFAULT NULL,
  `cod_amount` int(12) DEFAULT NULL,
  `cod_fee` int(12) DEFAULT NULL,
  `total_amount_collected` int(12) DEFAULT NULL,
  `carrier_signature` varchar(100) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bol_head`
--

INSERT INTO `bol_head` (`id`, `user_id`, `carrier_name`, `carrier_duns`, `carrier_phone`, `carrier_address`, `carrier_date`, `consignee`, `consignee_address`, `consignee_phone`, `third_party_billing`, `address`, `phone`, `bol_number`, `sid_number`, `sac`, `freight_bill_pro_number`, `load_number`, `trailer_number`, `trailer_type`, `special_instructions1`, `shipper_internal_date`, `special_instructions2`, `cod_amount`, `cod_fee`, `total_amount_collected`, `carrier_signature`, `status`, `createdAt`, `updatedAt`, `deletedAt`) VALUES
(1, 1, 'Test', 'Test', 'Test', 'Test', '2019-09-08 18:30:00', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 10, 10, 10, 'Test', 10, '2019-09-24 03:19:51', '2019-09-24 03:19:51', NULL),
(2, 1, 'Test', 'Test', 'Test', 'Test', '2019-09-08 18:30:00', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 10, 10, 10, 'Test', 10, '2019-09-24 03:22:44', '2019-09-24 03:22:44', NULL),
(3, 1, 'Test', 'Test', 'Test', 'Test', '2019-09-08 18:30:00', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 10, 10, 10, 'Test', 10, '2019-09-24 03:22:45', '2019-09-24 03:22:45', NULL),
(4, 1, 'Test', 'Test', 'Test', 'Test', '2019-09-08 18:30:00', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 'Test', 10, 10, 10, 'Test', 10, '2019-09-24 03:22:46', '2019-09-24 03:22:46', NULL),
(5, 3, 'Test update', 'Test update', 'Test update', 'Test update', '2019-09-08 18:30:00', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 'Test update', 10, 10, 10, 'Test update', 10, '2019-09-24 03:23:49', '2019-09-24 04:21:55', NULL),
(9, 3, 'fsdf', 'sdfsd', 'sdf', 'sdfsdf', NULL, 'sdf', 'sdf', '4234', 'sdfs', 'sdf', '2342', 'df', '2342', '34234', 'sdf', '34234', '23424', '234', '23424', '2019-09-12', 'sdfsdf', 23432, 42, 234, 'dfsdfdsf', 0, '2019-09-25 03:47:58', '2019-09-25 03:47:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `bol_item_detail`
--

CREATE TABLE `bol_item_detail` (
  `id` int(4) NOT NULL,
  `bol_head_id` int(4) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `summary` varchar(200) DEFAULT NULL,
  `item_code` varchar(100) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT NULL,
  `description` text,
  `packging` varchar(100) DEFAULT NULL,
  `class` varchar(100) DEFAULT NULL,
  `hm` varchar(100) DEFAULT NULL,
  `weight` decimal(10,2) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bol_item_detail`
--

INSERT INTO `bol_item_detail` (`id`, `bol_head_id`, `name`, `summary`, `item_code`, `quantity`, `description`, `packging`, `class`, `hm`, `weight`, `createdAt`, `updatedAt`, `deletedAt`) VALUES
(1, 1, 'Test', 'Test', 'Test', '15.00', 'Test', 'Test', 'Test', 'Test', '10.00', '2019-09-24 03:19:51', '2019-09-24 03:19:51', NULL),
(2, 1, 'Test', 'Test', 'Test', '15.00', 'Test', 'Test', 'Test', 'Test', '10.00', '2019-09-24 03:19:51', '2019-09-24 03:19:51', NULL),
(3, 2, 'Test', 'Test', 'Test', '15.00', 'Test', 'Test', 'Test', 'Test', '10.00', '2019-09-24 03:22:44', '2019-09-24 03:22:44', NULL),
(4, 2, 'Test', 'Test', 'Test', '15.00', 'Test', 'Test', 'Test', 'Test', '10.00', '2019-09-24 03:22:44', '2019-09-24 03:22:44', NULL),
(5, 3, 'Test', 'Test', 'Test', '15.00', 'Test', 'Test', 'Test', 'Test', '10.00', '2019-09-24 03:22:45', '2019-09-24 03:22:45', NULL),
(6, 3, 'Test', 'Test', 'Test', '15.00', 'Test', 'Test', 'Test', 'Test', '10.00', '2019-09-24 03:22:45', '2019-09-24 03:22:45', NULL),
(7, 4, 'Test', 'Test', 'Test', '15.00', 'Test', 'Test', 'Test', 'Test', '10.00', '2019-09-24 03:22:46', '2019-09-24 03:22:46', NULL),
(8, 4, 'Test', 'Test', 'Test', '15.00', 'Test', 'Test', 'Test', 'Test', '10.00', '2019-09-24 03:22:46', '2019-09-24 03:22:46', NULL),
(9, 5, 'Test update', 'Test update', 'Test update', '445.00', 'Test update', 'Test update', 'Test update', 'Test update', '586.00', '2019-09-24 03:23:49', '2019-09-24 04:21:55', NULL),
(10, 5, 'Test update', 'Test update', 'Test update', '445.00', 'Test update', 'Test update', 'Test update', 'Test update', '586.00', '2019-09-24 03:23:49', '2019-09-24 04:21:55', NULL),
(11, 5, 'Test 2', 'Test 2', 'Test 2', '156.00', 'Test 3', 'Test 3', 'Test 3', 'Test 3', '145.00', '2019-09-24 03:28:17', '2019-09-24 03:28:17', NULL),
(12, 5, 'Test update 2', 'Test update 2', 'Test update 2', '156.00', 'Test update 3', 'Test update 3', 'Test update 3', 'Test update 3', '145.00', '2019-09-24 03:29:06', '2019-09-24 03:29:06', NULL),
(13, 5, 'Test update 2', 'Test update 2', 'Test update 2', '156.00', 'Test update 3', 'Test update 3', 'Test update 3', 'Test update 3', '145.00', '2019-09-24 04:21:55', '2019-09-24 04:21:55', NULL),
(14, 9, NULL, NULL, '432', '234.00', '234', '342', '4', '23', '423.00', '2019-09-25 03:47:58', '2019-09-25 03:47:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(4) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `phone_number` varchar(40) NOT NULL,
  `email` varchar(100) NOT NULL,
  `company_type` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `company_name`, `phone_number`, `email`, `company_type`, `password`, `createdAt`, `updatedAt`, `deletedAt`) VALUES
(1, 'Parshav Shah', 'test', 'parshavshah1@gmail.com', '', '123456', '2019-09-22 15:26:48', '2019-09-22 15:26:48', NULL),
(2, 'Parshav Shah', 'test', 'parshavshah2@gmail.com', '', '123456', '2019-09-22 15:39:07', '2019-09-22 15:39:07', NULL),
(3, 'Parshav', '54545445454', 'parshav@gmail.com', 'something', 'sha1$4594d67b$1$71fbe3269af47caf62fd3e34560cbf8f7323fbe2', '2019-09-24 03:17:30', '2019-09-24 03:17:30', NULL),
(4, 'navi', '7778151390', 'navu@gmail.com', 'Company 3', 'sha1$ca115fc0$1$e905b6b72cf25462834da4bdeb2091d534053a5f', '2019-09-24 04:29:19', '2019-09-24 04:29:19', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bol_head`
--
ALTER TABLE `bol_head`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_fk_key` (`user_id`);

--
-- Indexes for table `bol_item_detail`
--
ALTER TABLE `bol_item_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bol_head`
--
ALTER TABLE `bol_head`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `bol_item_detail`
--
ALTER TABLE `bol_item_detail`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bol_head`
--
ALTER TABLE `bol_head`
  ADD CONSTRAINT `user_fk_key` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
