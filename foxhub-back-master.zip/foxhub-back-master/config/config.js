module.exports = {
    development: {
        username: "root",
        password: "root",
        database: "foxhub",
        host: "localhost",
        dialect: 'mysql',
        key: 'parshav123',
        use_env_variable: 'DATABASE_URL'
    }
};