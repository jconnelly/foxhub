var ResponseManager = require('../helper/ResponseManager');
var Models = require('../models/');
var Sequelize = require('sequelize');

/**
 * @name : List
 * @description : to list the records
 * @author : Parshav Shah
 */
exports.List = async (req, res) => {
    try {

        // find the accounts
        let BolHead = await Models.BolHead.findAll({
            where: {
                user_id: req.user.id
            },
            include: [{
                model: Models.BolItemDetail,
                required: false
            }]
        }).catch((error) => {
            throw error;
        })

        if (!BolHead) {
            throw new Error("BOLs not exist");
        }

        res.data = BolHead;
        res.message = "BOLs fetched successfully";

        ResponseManager.SendResponse(res);

    } catch (error) {
        console.log(error)
        res.code = 500;
        res.message = error.message;
        res.data = error;
        ResponseManager.SendResponse(res);
    }
}

/**
 * @name : Create
 * @description : to create the record
 * @author : Parshav Shah
 */
exports.Create = async (req, res) => {
    let TransectionId = await Models.sequelize.transaction();
    try {

        let Options = {
            transaction: TransectionId
        }

        // Head data preparation and saving process
        let HeadData = JSON.parse(JSON.stringify(req.body));
        HeadData['user_id'] = (req && req.user && req.user.id) ? req.user.id : 1;
        delete HeadData['BolItemDetails'];
        delete HeadData['id'];
        let Result = await Models.BolHead.create(HeadData, Options).catch((error) => { throw error; });

        // Detail data preparation and saving process
        let DetailData = [];
        if (req.body['BolItemDetails'] && req.body['BolItemDetails'].length) {
            req.body['BolItemDetails'].forEach(bid => {
                bid['bol_head_id'] = Result['id']
                delete bid['id'];
                DetailData.push(JSON.parse(JSON.stringify(bid)))
            });
        }
        Result['BolItemDetails'] = await Models.BolItemDetail.bulkCreate(DetailData, Options).catch((error) => { throw error; });

        TransectionId.commit();

        res['code'] = 201;
        res['data'] = Result;
        res['message'] = "BOL created";

        // Send the response
        ResponseManager.SendResponse(res);

    } catch (error) {
        TransectionId.rollback();
        res['code'] = 500;
        res['message'] = error.message;
        res['data'] = error;
        ResponseManager.SendResponse(res);
    }
}

/**
 * @name : Update
 * @description : to update the record
 * @author : Parshav Shah
 */
exports.Update = async (req, res) => {
    let Id = req.params.id;
    let TransectionId = await Models.sequelize.transaction();
    try {

        let Options = {
            transaction: TransectionId
        }

        // Head data preparation and update process
        let HeadData = JSON.parse(JSON.stringify(req.body));
        HeadData['user_id'] = req.user.id;
        delete HeadData['BolItemDetails'];
        delete HeadData['id'];
        await Models.BolHead.update(HeadData, {
            transaction: TransectionId,
            where: {
                id: Id
            }
        }).catch((error) => { throw error; });

        // Detail data preparation and update process
        let DetailDataCreate = [];
        let DetailDataUpdate = [];
        if (req.body['BolItemDetails'] && req.body['BolItemDetails'].length) {
            req.body['BolItemDetails'].forEach(bid => {
                if (bid['id'] == null) {
                    bid['bol_head_id'] = Id;
                    DetailDataCreate.push(bid);
                } else {
                    DetailDataUpdate.push(bid)
                }
            });
        }
        if (DetailDataCreate && DetailDataCreate.length) {
            await Models.BolItemDetail.bulkCreate(DetailDataCreate, Options).catch((error) => { throw error; });
        }
        if (DetailDataUpdate && DetailDataUpdate.length) {
            for (const i in DetailDataUpdate) {
                if (DetailDataUpdate.hasOwnProperty(i)) {
                    const UpdateIt = DetailDataUpdate[i];
                    await Models.BolItemDetail.update(UpdateIt, {
                        transaction: TransectionId,
                        where: {
                            id: UpdateIt['id']
                        }
                    }).catch((error) => { throw error; });
                }
            }
        }

        TransectionId.commit();

        res['code'] = 201;
        res['data'] = [];
        res['message'] = "BOL updated";

        // Send the response
        ResponseManager.SendResponse(res);

    } catch (error) {
        console.log(error)
        TransectionId.rollback();
        res['code'] = 500;
        res['message'] = error.message;
        res['data'] = error;
        ResponseManager.SendResponse(res);
    }
}

/**
 * @name : Read
 * @description : to read the record
 * @author : Parshav Shah
 */
exports.Read = async (req, res) => {
    try {
        var Id = req.params.id;

        // find the accounts
        let Account = await Models.BolHead.findOne({
            where: {
                id: Id,
                user_id: req.user.id
            },
            include: [{
                model: Models.BolItemDetail,
                required: false
            }]
        }).catch((error) => {
            throw error;
        })

        if (!Account) {
            throw new Error("Bol not exist");
        }

        res.data = Account;
        res.message = "Bol fetched successfully";

        ResponseManager.SendResponse(res);

    } catch (error) {
        console.log(error)
        res.message = error.message;
        res.data = error;
        ResponseManager.SendResponse(res);
    }
}

/**
 * @name : Delete
 * @description : to delete the record
 * @author : Parshav Shah
 */
exports.Delete = async (req, res) => {
    try {

        var AccountId = req.params.id;

        let Account = {};

        // check that account is exist or not
        Account = await Models.BolHead.findOne({
            where: {
                id: AccountId,
                user_id: req.user.id
            }
        }).catch((error) => {
            throw error;
        })

        // User not exist so create the user
        if (Account) {
            Account = await Models.BolHead.destroy({
                where: {
                    id: AccountId
                }
            }).catch((error) => {
                throw error;
            });
            res['message'] = "Account deleted";
        }
        // User exist so throw the error
        else {
            throw new Error("Account Not Exist");
        }

        // Send the response
        ResponseManager.SendResponse(res);

    } catch (error) {
        res['message'] = error.message;
        res['data'] = error;
        ResponseManager.SendResponse(res);
    }
}