const Joi = require('@hapi/joi');
var ResponseManager = require('../helper/ResponseManager');

const RequestSchema = Joi.object({
      id: Joi.number().required().allow(null),
      company_name: Joi.string().required().allow(null),
      phone_number: Joi.string().required().allow(null),
      email: Joi.string().required().allow(null),
      company_type: Joi.string().required().allow(null),
      password: Joi.string().required().allow(null)
})

exports.Validate = async (req, res, next) => {
      try {

            const Result = await RequestSchema.validateAsync(req.body, { abortEarly: false }).catch((error) => {
                  throw error;
            })

            if (Result) {
                  next();
            } else {
                  throw new Error("Something went wrong");
            }

      } catch (error) {
            res.code = 500;
            res.message = error.message;
            res.data = error.details;
            ResponseManager.SendResponse(res);
      }
}