import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-contact',
  templateUrl: './my-contact.component.html',
  styleUrls: ['./my-contact.component.css']
})
export class MyContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
