import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UtilsService } from '../services/utils.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  form: FormGroup;

  constructor(
    public fb: FormBuilder,
    public utilservice: UtilsService,

  ) { }

  ngOnInit() {
    this.initForm();
  }

  initForm() {
    this.form = this.fb.group({
      id: [null, Validators.required],
      company_name: [null, Validators.required],
      phone_number: [null, Validators.required],
      email: [null, Validators.required],
      company_type: [null, Validators.required],
      password: [null, Validators.required],
    });
  }

  submit() { 
    let userData = this.form.getRawValue();
    console.log(userData);
    this.utilservice.makeAPICall(this.utilservice.postMethod, 'user/register', userData, (callback) => {
      console.log(callback);
      if (!this.utilservice.isEmptyObject(callback.data)) {
        this.utilservice.goToPage('/login');
      }
    });
  }

}
