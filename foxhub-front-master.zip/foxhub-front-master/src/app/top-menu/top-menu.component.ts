import { BolFormComponent } from './../bol-form/bol-form.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.css']
})
export class TopMenuComponent implements OnInit {

  constructor(private bolFormModel: NgbModal) { }

  ngOnInit() {
  }

  openBolForm() {
    const Form = this.bolFormModel.open(BolFormComponent, {
      size: 'xl',
      windowClass: 'customizeModal'
    });
  }
}
