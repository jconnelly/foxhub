import { Component, OnInit } from '@angular/core';
import { UtilsService } from '../services/utils.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form: FormGroup;
  error: boolean;
  constructor(
    public utilservice: UtilsService,
    public fb: FormBuilder,
  ) { }

  ngOnInit() {
    this.initForm();
  }

  initForm() {
    this.form = this.fb.group({
      email: [null, Validators.required],
      password: [null, Validators.required]
    });
  }

  submit() {
    let userData = this.form.getRawValue();
    console.log(userData);
    this.utilservice.makeAPICall(this.utilservice.postMethod, 'user/login', userData, (callback) => {
      console.log(callback);
      if (!this.utilservice.isEmptyObject(callback.data)) {
        if (callback.data.token) {
          localStorage.setItem('token', callback.data.token)
        }
        this.utilservice.goToPage('/dashboard');
      } else {
        this.error = true;
      }
    });
  }
  register() {
    this.utilservice.goToPage('/register');
  }

}
