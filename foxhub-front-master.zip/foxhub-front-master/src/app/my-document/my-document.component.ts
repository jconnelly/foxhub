import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-document',
  templateUrl: './my-document.component.html',
  styleUrls: ['./my-document.component.css']
})
export class MyDocumentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
