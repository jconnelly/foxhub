import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, FormArray, Validators } from '@angular/forms';
import { UtilsService } from '../services/utils.service';

@Component({
  selector: 'app-bol-form',
  templateUrl: './bol-form.component.html',
  styleUrls: ['./bol-form.component.css']
})
export class BolFormComponent implements OnInit {
  submitted: boolean;
  bolForm: FormGroup;
  carrierItems: FormArray;
  activeTab = 'one';
  error: boolean;
  changeTab(tab) {
    this.submitted = true;
    this.activeTab = tab;
  }

  constructor(public activeModal: NgbActiveModal, private fb: FormBuilder, public utilservice: UtilsService) { }

  ngOnInit() {
    this.createBolForm();
    // console.log(this.bolForm.value);
  }

  createBolForm() {
    this.bolForm = this.fb.group({
      id: [null],
      carrier_name: [null, Validators.required],
      carrier_duns: [null, Validators.required],
      carrier_phone: [null, Validators.required],
      carrier_address: [null, Validators.required],
      carrier_date: [null, Validators.required],
      consignee: [null, Validators.required],
      consignee_address: [null, Validators.required],
      consignee_phone: [null, Validators.required],
      third_party_billing: [null, Validators.required],
      address: [null, Validators.required],
      phone: [null, Validators.required],
      bol_number: [null, Validators.required],
      sid_number: [null, Validators.required],
      sac: [null, Validators.required],
      freight_bill_pro_number: [null, Validators.required],
      load_number: [null, Validators.required],
      trailer_number: [null, Validators.required],
      trailer_type: [null, Validators.required],
      special_instructions1: [null, Validators.required],
      shipper_internal_date: [null, Validators.required],
      special_instructions2: [null, Validators.required],
      cod_amount: [null, Validators.required],
      cod_fee: [null, Validators.required],
      total_amount_collected: [null, Validators.required],
      carrier_signature: [null, Validators.required],
      status: [0],
      BolItemDetails: this.fb.array([this.createCarrierItem()]),
    });
  }

  createCarrierItem() {
    return this.fb.group({
      id: [null],
      name: [null, Validators.required],
      summary: [null],
      item_code: [null, Validators.required],
      quantity: [null, Validators.required],
      description: [null, Validators.required],
      packging: [null, Validators.required],
      class: [null, Validators.required],
      hm: [null, Validators.required],
      weight: [null, Validators.required]
    });
  }

  addCarrierItem() {
    this.carrierItems = this.bolForm.get('BolItemDetails') as FormArray;
    this.carrierItems.push(this.createCarrierItem());
  }

  closeModal() {
    this.activeModal.close('Modal Closed');
  }
  submit() {
    this.submitted = true;
    if (this.bolForm.invalid) return true;
    let userData = this.bolForm.getRawValue();
    console.log(userData);
    this.utilservice.makeAPICall(this.utilservice.postMethod, 'bol', userData, (callback) => {
      console.log(callback);
      if (!this.utilservice.isEmptyObject(callback.data)) {
        if (callback.data.token) {
          localStorage.setItem('token', callback.data.token)
        }
        this.utilservice.goToPage('/dashboard');
      } else {
        this.error = true;
      }
    });
  }

}
