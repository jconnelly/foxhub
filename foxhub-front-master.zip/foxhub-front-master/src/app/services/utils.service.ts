import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

declare var $: any;
@Injectable()
export class UtilsService {
  postMethod = "POST";
  getMethod = "GET";
  patchMethod = "PATCH";

  // URL = "http://192.168.2.161:8080/accounting/"; // BHARTI  PC
  // URL = "http://192.168.2.162:8080/accounting/"; // VISHVAS PC
  URL = "http://192.168.2.111:3200/"; // Server
  constructor(
    private router: Router,
    public httpClient: HttpClient) {

  }
  goToPage(url) {
    this.router.navigateByUrl(url);
  }
  /*
  *
  * Used to check if object ios empaty or not..!
  * @param obj = "indecated object which you want to check"
  * return true if empty..!
  */
  isEmptyObject(obj) {
    return (obj && (Object.keys(obj).length === 0));
  }
  /**
   * This Is Used For API Call.
   * @param methodName Method Name Like , : GET , POST , DELETE :)
   * @param url Your Selected API Name.
   * @param params Parmas For POST method.
   * @param callback Server Response.
   */
  makeAPICall(methodName, url, params, callback: (response) => void) {

    url = this.URL + url;
    let token = localStorage.getItem('token');

    let headers = new HttpHeaders().set('Content-Type', 'application/json');
    if (token) {
      headers = headers.set('authorization', token); 
    }
    // Make the HTTP request:
    if (methodName == this.getMethod) {
      // console.log(params);
      url += params;
      // console.log(url);
      return this.httpClient.get(url, {
        headers: headers
      }).subscribe(response => {
        // Read the result field from the JSON response. 
        callback(response);
      },
        (err: HttpErrorResponse) => {
          if (err.error instanceof Error) {
            // A client-side or network error occurred. Handle it accordingly.
            // console.log('An error occurred:', err.error.message);
          } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            // console.log(`Backend returned code ${err.status}, body was: ${err.error}`);
          }
        }
      );
    } else if (methodName == this.postMethod) {
      return this.httpClient.post(url, params, {
        headers: headers
      }).subscribe(response => {
        callback(response);
      },
        (err: HttpErrorResponse) => {
          if (err.error instanceof Error) {
            // A client-side or network error occurred. Handle it accordingly.
            // console.log('An error occurred:', err.error.message);
          } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            // console.log(`Backend returned code ${err.status}, body was: ${err.error}`);
          }
        }
      );
    }
    else if (methodName == this.patchMethod) {
      return this.httpClient.patch(url, params, {
        // params: new HttpParams().set('id', '3'),
      }).subscribe(response => {
        callback(response);
      },
        (err: HttpErrorResponse) => {
          if (err.error instanceof Error) {
            // A client-side or network error occurred. Handle it accordingly.
            // console.log('An error occurred:', err.error.message);
          } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong,
            // console.log(`Backend returned code ${err.status}, body was: ${err.error}`);
          }
        }
      );
    }
  }




}
